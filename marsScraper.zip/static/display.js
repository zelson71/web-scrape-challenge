// document.addEventListener('DOMContentLoaded', (event) => 

function display() {
    window.onload = function () {
        var NAME = document.querySelector(".peekaboo")
        NAME.className = "show"
    }


}



